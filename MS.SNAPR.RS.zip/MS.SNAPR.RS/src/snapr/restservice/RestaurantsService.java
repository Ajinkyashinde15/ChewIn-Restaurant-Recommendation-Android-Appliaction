package snapr.restservice;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

///Sets the path of the web services and gets the data from the DAO objects
@Path("/Service")
public class RestaurantsService {

   RestaurantsDao restaurantDAO= new RestaurantsDao();
   BookmarksDao bookmarksDAO=new BookmarksDao();
   CheckInDao checkinDAO= new CheckInDao();
   RatingDao ratingDAO=new RatingDao();
   
  //web service to get the details of the recommended restaurants
   @GET
   @Path("/RecommendedRestaurants")
   @Produces(MediaType.APPLICATION_XML)
   public List<Restaurant> getRecommendedRestaurants(){
      return restaurantDAO.GetRecommendedRestaurants();
   }	
   //web service to get the details of the menu restaurants
   @GET
   @Path("/MenuRestaurants")
   @Produces(MediaType.APPLICATION_XML)
   public List<Restaurant> getMenuRestaurants(){
      return restaurantDAO.GetMenuRestaurants();
   }
   //web service to get the details of the bookmarked restaurants
   @GET
   @Path("/BookmarkRestaurants")
   @Produces(MediaType.APPLICATION_XML)
   public List<Bookmark> getBookmarkRestaurants(){
      return bookmarksDAO.GetBookmarkedRestaurants();
   }
   //web service to get the details of the checked in restaurants
   @GET
   @Path("/CheckInRestaurants")
   @Produces(MediaType.APPLICATION_XML)
   public List<CheckIn> getCheckInRestaurants(){
      return checkinDAO.GetCheckInRestaurants();
   }
   //web service to get the details of the ratings
   @GET
   @Path("/RatingRestaurants")
   @Produces(MediaType.APPLICATION_XML)
   public List<Rating> getRatings(){
      return ratingDAO.GetRatings();
   }
}

package snapr.restservice;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


//creates a rating class to display data in the RESP API and post it in the webs service in XML format
@XmlRootElement(name = "rating")
public class Rating implements Serializable {
	private static final long serialVersionUID = 1L;
	private String userid;
	private String resid;
	private String rating;
	
	public Rating(){}

	public Rating(String userid, String resid,String rating)
	{
		this.userid=userid;
		this.resid = resid;
		this.rating=rating;
	}
	public String getResID() {
		return resid;
	}
	@XmlElement
	public void setResID(String resid) {
		this.resid = resid;
	}
	public String getUserID() {
		return userid;
	}
	@XmlElement
	public void setUserID(String userid) {
		this.userid = userid;
	}	
	public String getRating() {
		return rating;
	}

	@XmlElement
	public void setRating(String rating) {
		this.rating = rating;
	}

}

package snapr.restservice;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


//creates a restaurant class to display data in the RESP API and post it in the webs service in XML format
@XmlRootElement(name = "restaurant")
public class Restaurant implements Serializable {

	private static final long serialVersionUID = 1L;
	private String rid;
	private String name;
	private String longitude;
	private String latitude;
	private String cuisines;
	private String average_cost;
	private String price_range;
	private String aggregate_rating;
	private String thumb;
	private String phone_numbers;
	private String url;
	private String address;
	private String votes;
	private String rating_text;

	public Restaurant(){}

	public Restaurant(String rid, String name, String longitude, String latitude, String cuisine, String average_cost, String price_range,String aggregate_rating,String thumb,String phone_numbers,String url,String address,String votes, String rating_text)
	{
		this.rid = rid;
		this.name = name;
		this.longitude = longitude;
		this.latitude=latitude;
		this.cuisines=cuisine;
		this.average_cost=average_cost;
		this.price_range=price_range;
		this.aggregate_rating=aggregate_rating;
		this.thumb=thumb;
		this.phone_numbers=phone_numbers;
		this.url=url;
		this.votes=votes;
		this.rating_text=rating_text;
		this.address=address;
	}

	public String getId() {
		return rid;
	}

	@XmlElement
	public void setId(String rid) {
		this.rid = rid;
	}
	public String getName() {
		return name;
	}
	@XmlElement
	public void setName(String name) {
		this.name = name;
	}
	public String getLongitude() {
		return longitude;
	}
	@XmlElement
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}	
	public String getLatitude() {
		return latitude;
	}

	@XmlElement
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getCuisines() {
		return cuisines;
	}

	@XmlElement
	public void setCuisines(String cuisine) {
		this.cuisines = cuisine;
	}
	public String getAverageCost() {
		return average_cost;
	}

	@XmlElement
	public void setAverageCost(String average_cost) {
		this.average_cost = average_cost;
	}
	public String getPriceRange() {
		return price_range;
	}

	@XmlElement
	public void setPriceRange(String price_range) {
		this.price_range = price_range;
	}
	
	public String getThumb() {
		return thumb;
	}

	@XmlElement
	public void setThumb(String thumb) {
		this.thumb = thumb;
	}
	
	public String getAggregateRating() {
		return aggregate_rating;
	}

	@XmlElement
	public void setAggregateRating(String aggregate_rating) {
		this.aggregate_rating = aggregate_rating;
	}
	
	public String getPhoneNumbers() {
		return phone_numbers;
	}

	@XmlElement
	public void setPhoneNumbers(String phone_numbers) {
		this.phone_numbers = phone_numbers;
	}
	
	public String getUrl() {
		return url;
	}

	@XmlElement
	public void setUrl(String url) {
		this.url = url;
	}
	
	public String getVotes() {
		return votes;
	}

	@XmlElement
	public void setVotes(String votes) {
		this.votes = votes;
	}
	
	public String getRatingText() {
		return rating_text;
	}

	@XmlElement
	public void setRatingText(String rating_text) {
		this.rating_text = rating_text;
	}
	
	public String getAddress() {
		return address;
	}

	@XmlElement
	public void setAddress(String address) {
		this.address = address;
	}
}

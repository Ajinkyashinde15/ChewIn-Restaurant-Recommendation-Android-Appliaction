package snapr.restservice;


import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

//A bookmark class to read and display in the REST API
@XmlRootElement(name = "bookmark")
public class Bookmark implements Serializable {

	private static final long serialVersionUID = 1L;
	private String resname;
	private String longitude;
	private String latitude;
	
	public Bookmark(){}

	public Bookmark(String resname, String longitude, String latitude)
	{
		this.resname=resname;
		this.longitude = longitude;
		this.latitude=latitude;
	}

	public String getResName() {
		return resname;
	}
	@XmlElement
	public void setResName(String resname) {
		this.resname = resname;
	}
	public String getLongitude() {
		return longitude;
	}
	@XmlElement
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}	
	public String getLatitude() {
		return latitude;
	}

	@XmlElement
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	
}

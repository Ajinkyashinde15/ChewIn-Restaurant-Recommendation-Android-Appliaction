package snapr.restservice;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

//creates a check in class to display data in the RESP API and post it in the webs service in XML format
@XmlRootElement(name = "checkin")
public class CheckIn implements Serializable {
	private static final long serialVersionUID = 1L;
	private String resname;
	private String longitude;
	private String latitude;
	
	public CheckIn(){}

	public CheckIn(String resname, String longitude, String latitude)
	{
		this.resname=resname;
		this.longitude = longitude;
		this.latitude=latitude;
	}
	public String getResName() {
		return resname;
	}
	@XmlElement
	public void setResName(String resname) {
		this.resname = resname;
	}
	public String getLongitude() {
		return longitude;
	}
	@XmlElement
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}	
	public String getLatitude() {
		return latitude;
	}

	@XmlElement
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
}

package snapr.restservice;

import java.util.ArrayList;
import java.util.List;

import snapr.dal.BookmarksDAL;
import snapr.dal.UserDAL;

public class BookmarksDao {
	//Create a list of bookmark class
	private static List<Bookmark> BookmarkedRestaurants=new ArrayList<Bookmark>();
	//Get all the bookmarked restaurants for the current user and host it on the web service
	public List<Bookmark> GetBookmarkedRestaurants() {
		BookmarkedRestaurants.clear();
		BookmarksDAL bookmarksDal=new BookmarksDAL();
		if(bookmarksDal.GetConnection())
		{
			bookmarksDal.GetAllBookmarks(UserDAL.userid);
		}
		return BookmarkedRestaurants;
	}
	public void AddBookmarkedRestaurants(Bookmark bm)
	{
		BookmarkedRestaurants.add(bm);
	}
}

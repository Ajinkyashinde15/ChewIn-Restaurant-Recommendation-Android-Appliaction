package snapr.restservice;

import java.util.ArrayList;
import java.util.List;

import snapr.dal.RatingDAL;
import snapr.dal.UserDAL;

//creates and  gets data from the ratings data table
public class RatingDao {

	//Creates a list of ratings object to store and display the ratings data in XML format
	private static List<Rating> Ratings=new ArrayList<Rating>();
	public List<Rating> GetRatings() {
		Ratings.clear();
		RatingDAL ratingDal=new RatingDAL();
		if(ratingDal.GetConnection())
		{
			ratingDal.GetAllRatings(UserDAL.userid);
		}
		return Ratings;
	}

//Add a new instance to the array list
	public void AddRatings(Rating r)
	{
		Ratings.add(r);
	}
}

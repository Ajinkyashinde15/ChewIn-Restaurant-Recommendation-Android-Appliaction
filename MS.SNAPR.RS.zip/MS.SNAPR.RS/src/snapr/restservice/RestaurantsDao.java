package snapr.restservice;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;



public class RestaurantsDao {

	///Creates a list of restaurants object to store and display the restaurants data in XML format
	//First object is to store the recommended restaurants
	private static List<Restaurant> recommendedRestaurants=new ArrayList<Restaurant>();
	//Second object is to store the menu restaurants
	private static List<Restaurant> menuRestaurants=new ArrayList<Restaurant>();
	
	
	public List<Restaurant> GetRecommendedRestaurants() {
		return recommendedRestaurants;
	}

	//add restaurant ids to the array list
	public void AddRecommendedRestaurants(Restaurant restro)
	{
		recommendedRestaurants.add(restro);
	}
	public List<Restaurant> GetMenuRestaurants() {
		return menuRestaurants;
	}

	//add restaurant ids to the array list
	public void AddMenuRestaurants(Restaurant restro)
	{
		menuRestaurants.add(restro);
	}
	//Once we get all the recommneded restaurant ids, we get details from the Zomato API to send details to the webs service
	public void GetRecommendedRestaurantsFromAPI(ArrayList<Integer> Ids)
	{
		recommendedRestaurants.clear();
		JSONParser parser = new JSONParser();
		int i=0;
		for(Integer resId:Ids)
		{
			if(i<10)
			{
				try
				{
					URL zomatourl = new URL("https://developers.zomato.com/api/v2.1/restaurant?res_id="+resId);
					HttpURLConnection urlConnection = (HttpURLConnection) zomatourl.openConnection();
					urlConnection.setRequestProperty("user_key", "b6728b744dbec3f54fb5cce3ab6d62d2");
					urlConnection.setRequestMethod("GET");
					urlConnection.setRequestProperty("User-Agent", "curl/7.43.0");
					urlConnection.setRequestProperty("Accept", "application/json");
					urlConnection.setDoOutput(false);
					urlConnection.connect();

					InputStream inputStream = urlConnection.getInputStream();
					StringBuffer buffer = new StringBuffer();

					if (inputStream == null) {
						return;
					}
					BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
					String line;


					while ((line = br.readLine()) != null) {
						try
						{
							buffer.append(line + "\n");
							//System.out.println(line);
							Object obj=parser.parse(line);
							JSONObject jsonObject = (JSONObject) obj;

							String rid = (String) jsonObject.get("id");
							String name = (String) jsonObject.get("name");
							String cuisine = (String) jsonObject.get("cuisines");

							Object objLocation=parser.parse(jsonObject.get("location").toString());
							JSONObject jsonObjectLocation = (JSONObject) objLocation;
							String longitude = (String) jsonObjectLocation.get("longitude");
							String latitude = (String) jsonObjectLocation.get("latitude");
							String address = (String) jsonObjectLocation.get("address");

							String average_cost = ((Long) jsonObject.get("average_cost_for_two")).toString();
							String price_range = ((Long) jsonObject.get("price_range")).toString();


							Object objRating=parser.parse(jsonObject.get("user_rating").toString());
							JSONObject jsonObjectRating = (JSONObject) objRating;
							String aggregate_rating = (String) jsonObjectRating.get("aggregate_rating");
							String votes = (String) jsonObjectRating.get("votes");
							String rating_text = (String) jsonObjectRating.get("rating_text");
							
							String thumb=(String)jsonObject.get("thumb");
							String phone_numbers=(String)jsonObject.get("phone_numbers");
							String url=(String)jsonObject.get("url");

							Restaurant restro= new Restaurant(rid, name, longitude, latitude, cuisine, average_cost, price_range, aggregate_rating, thumb, phone_numbers, url, address, votes, rating_text);
							this.AddRecommendedRestaurants(restro);
							System.out.println(jsonObject);
						}
						catch(Exception e)
						{
							e.printStackTrace();
						}
					}
					if (buffer.length() == 0) {
						return;
					}
				}
				catch(MalformedURLException e)
				{
					e.printStackTrace();
				}
				catch(IOException e)
				{
					e.printStackTrace();
				}
			}
			i++;
		}
	}
	//Once we get all the menu restaurant ids, we get details from the Zomato API to send details to the webs service
	public void GetMenuRestaurantsFromAPI(ArrayList<Integer> Ids)
	{
		menuRestaurants.clear();
		JSONParser parser = new JSONParser();
		int i=0;
		for(Integer resId:Ids)
		{
			if(i<10)
			{
				try
				{
					URL zomatourl = new URL("https://developers.zomato.com/api/v2.1/restaurant?res_id="+resId);
					HttpURLConnection urlConnection = (HttpURLConnection) zomatourl.openConnection();
					urlConnection.setRequestProperty("user_key", "b6728b744dbec3f54fb5cce3ab6d62d2");
					urlConnection.setRequestMethod("GET");
					urlConnection.setRequestProperty("User-Agent", "curl/7.43.0");
					urlConnection.setRequestProperty("Accept", "application/json");
					urlConnection.setDoOutput(false);
					urlConnection.connect();

					InputStream inputStream = urlConnection.getInputStream();
					StringBuffer buffer = new StringBuffer();

					if (inputStream == null) {
						return;
					}
					BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
					String line;


					while ((line = br.readLine()) != null) {
						try
						{
							buffer.append(line + "\n");
							Object obj=parser.parse(line);
							JSONObject jsonObject = (JSONObject) obj;

							String rid = (String) jsonObject.get("id");
							String name = (String) jsonObject.get("name");
							String cuisine = (String) jsonObject.get("cuisines");

							Object objLocation=parser.parse(jsonObject.get("location").toString());
							JSONObject jsonObjectLocation = (JSONObject) objLocation;
							String longitude = (String) jsonObjectLocation.get("longitude");
							String latitude = (String) jsonObjectLocation.get("latitude");
							String address = (String) jsonObjectLocation.get("address");

							String average_cost = ((Long) jsonObject.get("average_cost_for_two")).toString();
							String price_range = ((Long) jsonObject.get("price_range")).toString();
							
							String thumb=(String)jsonObject.get("thumb");
							String phone_numbers=(String)jsonObject.get("phone_numbers");
							String url=(String)jsonObject.get("url");


							Object objRating=parser.parse(jsonObject.get("user_rating").toString());
							JSONObject jsonObjectRating = (JSONObject) objRating;
							String aggregate_rating = (String) jsonObjectRating.get("aggregate_rating");
							String votes = (String) jsonObjectRating.get("votes");
							String rating_text = (String) jsonObjectRating.get("rating_text");

							Restaurant restro= new Restaurant(rid, name, longitude, latitude, cuisine, average_cost, price_range, aggregate_rating, thumb, phone_numbers, url, address, votes,  rating_text);
							this.AddMenuRestaurants(restro);
							System.out.println(jsonObject);
						}
						catch(Exception e)
						{
							e.printStackTrace();
						}
					}
					if (buffer.length() == 0) {
						return;
					}
				}
				catch(MalformedURLException e)
				{
					e.printStackTrace();
				}
				catch(IOException e)
				{
					e.printStackTrace();
				}
			}
			i++;
		}
	}
}
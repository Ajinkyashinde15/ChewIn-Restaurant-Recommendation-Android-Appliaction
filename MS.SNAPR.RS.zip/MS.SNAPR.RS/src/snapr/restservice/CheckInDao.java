package snapr.restservice;

import java.util.ArrayList;
import java.util.List;

import snapr.dal.CheckInDAL;
import snapr.dal.UserDAL;
//Populates the REST API with the checked in restaurants of the current user.
public class CheckInDao {
	private static List<CheckIn> CheckedInRestaurants=new ArrayList<CheckIn>();

	//Gets all the checked in data for the user 
	public List<CheckIn> GetCheckInRestaurants() {
		CheckedInRestaurants.clear();
		CheckInDAL checkinDal=new CheckInDAL();
		if(checkinDal.GetConnection())
		{
			checkinDal.GetAllCheckIns(UserDAL.userid);
		}
		return CheckedInRestaurants;
	}
	public void AddCheckInRestaurants(CheckIn ci)
	{
		CheckedInRestaurants.add(ci);
	}

}

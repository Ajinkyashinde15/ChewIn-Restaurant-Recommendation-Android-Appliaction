package snapr.casebase;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import snapr.cases.Case;

public class Casebase 
{
	private Map<Integer,Case> cb; // A Hash Map that stores cases and it's corresponding Ids
	
	
	public Casebase()
	{
		cb = new HashMap<Integer,Case>();
	}
	
	//Add a new case
	public void addCase(final Integer id, final Case c)
	{
		cb.put(id, c);
	}
	
	//Get all the Ids of all the cases
	public Set<Integer> getIds()
	{
		return cb.keySet();
	}

	//Get a case with the given Id
	public Case getCase(final Integer id)
	{
		return cb.get(id);
	}
	
	//Get the number of cases stored in the Hash Map
	public int size()
	{
		return cb.size();
	}
}

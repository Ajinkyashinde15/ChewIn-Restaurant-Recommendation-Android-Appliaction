package snapr.csv;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import snapr.cases.RatingCase;
import snapr.cases.RestaurantCase;

public class CsvWriter1 {

	//Delimiter used in CSV file
	private static final String COMMA_DELIMITER = ",";
	private static final String NEW_LINE_SEPARATOR = "\n";

	//CSV file header
	private static final String RESTRO_FILE_HEADER = "id, name,latitude,longitude,cuisines,average_cost_for_two,price_range,aggregate_rating";
	private static final String RATING_FILE_HEADER = "userId,restaurantId,rating";

   //A method to write restauarnts into a csv file in the given path
	public void RestaurantCSVWriter(ArrayList<RestaurantCase> restros, String path)
	{
		File file = new File(path);
		file.getParentFile().mkdirs();
		FileWriter fileWriter=null;
		try
		{
			fileWriter=new FileWriter(file);
			for(RestaurantCase r:restros)
			{
				fileWriter.append(String.valueOf(r.getId()));
				fileWriter.append(COMMA_DELIMITER);
				fileWriter.append(String.valueOf(r.getName()));
				fileWriter.append(COMMA_DELIMITER);
				fileWriter.append(String.valueOf(r.getLongitude()));
				fileWriter.append(COMMA_DELIMITER);
				fileWriter.append(String.valueOf(r.getLatitude()));
				fileWriter.append(COMMA_DELIMITER);
				fileWriter.append(String.valueOf(r.getCuisineCSVFormat()));
				fileWriter.append(COMMA_DELIMITER);
				fileWriter.append(String.valueOf(r.getAverageCost()));
				fileWriter.append(COMMA_DELIMITER);
				fileWriter.append(String.valueOf(r.getPriceRange()));
				fileWriter.append(COMMA_DELIMITER);
				fileWriter.append(String.valueOf(r.getAggregateRating()));
				fileWriter.append(NEW_LINE_SEPARATOR);

			}
			System.out.println("CSV file was created successfully !!!");
		}
		catch(Exception e)
		{
			System.out.println("Error in CsvFileWriter !!!");
			e.printStackTrace();
		}
		finally 
		{
			try 
			{
				fileWriter.flush();
				fileWriter.close();
			}
			catch (IOException e) 
			{
				System.out.println("Error while flushing/closing fileWriter !!!");
				e.printStackTrace();
			}

		}

	}
	
	//A method to write ratings into a csv file in the given path.
	public void RatingsCSVWriter(ArrayList<RatingCase> ratings, String path)
	{
		File file = new File(path);
		file.getParentFile().mkdirs();
		FileWriter fileWriter=null;
		try
		{
			fileWriter=new FileWriter(file);
			fileWriter.append(RATING_FILE_HEADER.toString());

			fileWriter.append(NEW_LINE_SEPARATOR);

			for(RatingCase r:ratings)
			{
				fileWriter.append(String.valueOf(r.getId()));
				fileWriter.append(COMMA_DELIMITER);
				fileWriter.append(String.valueOf(r.getUid()));
				fileWriter.append(COMMA_DELIMITER);
				fileWriter.append(String.valueOf(r.getRating()));
				fileWriter.append(NEW_LINE_SEPARATOR);

			}
			System.out.println("CSV file was created successfully !!!");
		}
		catch(Exception e)
		{
			System.out.println("Error in CsvFileWriter !!!");
			e.printStackTrace();
		}
		finally 
		{
			try 
			{
				fileWriter.flush();
				fileWriter.close();
			}
			catch (IOException e) 
			{
				System.out.println("Error while flushing/closing fileWriter !!!");
				e.printStackTrace();
			}

		}

	}
}

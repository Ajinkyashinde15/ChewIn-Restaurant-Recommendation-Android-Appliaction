
package snapr.util;

import java.util.HashMap;
import java.util.Map;

public class Matrix 
{
	private Map<Integer,Map<Integer,Double>> matrix; // the data structure used to store case similarities
	
	//Create two dimensional hash map that can store integers as roe/column ids and a double for the similarity score
	public Matrix()
	{
		matrix = new HashMap<Integer,Map<Integer,Double>>();
	}
	
	//Given the row and column id add the similarity score to it.
	public void addElement(final Integer rowId, final Integer colId, final Double entry)
	{
		Map<Integer,Double> row = (matrix.containsKey(rowId)) ? matrix.get(rowId) : new HashMap<Integer,Double>();
		row.put(colId, entry);
		matrix.put(rowId, row);
	}
	
	//Gets you the similarity score where row id and column id is given.
	public Double getElement(final Integer rowId, final Integer colId)
	{
		return (matrix.containsKey(rowId)) ? matrix.get(rowId).get(colId) : null;
	}
	
	
	public String toString()
	{
		StringBuffer buf = new StringBuffer();
		for(Integer rowId: matrix.keySet())
			buf.append(rowId + " " + matrix.get(rowId) + "\n");
		return buf.toString();
	}
}

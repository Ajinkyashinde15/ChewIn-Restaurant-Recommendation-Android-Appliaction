package snapr.util.reader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.ArrayList;
import java.util.Set;
import java.util.StringTokenizer;

import snapr.casebase.Casebase;
import snapr.cases.RestaurantCase;

public class DataReader {

   //Gets the csv file path and reads from the files
	private Casebase cb; // stores case objects
	private Map<Integer,Map<Integer,Double>> userProfiles; // stores training user profiles
	private Map<String,Set<Integer>> cuisineList; //Initial cuisine list
	private Map<String,Map<String,Double>> cuisineSimMetric; // cuisine similarity metric
	private double maxSim; // maximum similarity weight between all the cuisines

	public DataReader(final String trainFile, final String restaurantFile)
	{
		userProfiles = readUserProfiles(trainFile,true);
		//testProfiles = readUserProfiles(testFile, false);
		readCasebase(restaurantFile,userProfiles);
		calculatecuisineSimMatrix();
	}

	
	public Set<Integer> getUserIds()
	{
		return userProfiles.keySet();
	}

	
	public Map<Integer,Double> getUserProfile(final Integer id)
	{
		return userProfiles.get(id);
	}
	
	
	public Casebase getCasebase()
	{
		return cb;
	}

	//reads from the train csv file to get the user ratings
	private Map<Integer,Map<Integer,Double>> readUserProfiles(final String filename, final boolean train) 
	{
		Map<Integer,Map<Integer,Double>> map = new HashMap<Integer,Map<Integer,Double>>();
		try
		{
			BufferedReader br = new BufferedReader(new FileReader(new File(filename)));
			String line;
			br.readLine(); // read in header line

			while ((line = br.readLine()) != null) 
			{
				StringTokenizer st = new StringTokenizer(line, ",");
				if(st.countTokens() != 3)
				{
					System.out.println("Error reading from file \"" + filename + "\"");
					System.exit(1);
				}

				Integer userId = new Integer(st.nextToken());
				Integer restaurantId = new Integer(st.nextToken());
				Double rating = new Double(st.nextToken());

				Map<Integer,Double> profile = (map.containsKey(userId) ? map.get(userId) : new HashMap<Integer,Double>());
				profile.put(restaurantId, rating);
				map.put(userId, profile);

			}

			br.close();
		}
		catch(IOException e)
		{
			e.printStackTrace();
			System.exit(0);
		}

		return map;
	}

	
	private void readCasebase(final String filename, final Map<Integer,Map<Integer,Double>> userProfiles) 
	{
		cb = new Casebase();
		cuisineList = new HashMap<String,Set<Integer>>();

		try
		{
			BufferedReader br = new BufferedReader(new FileReader(new File(filename)));
			String line;
			br.readLine();
			while ((line = br.readLine()) != null) 
			{
				StringTokenizer st = new StringTokenizer(line, ",");
				if(st.countTokens() <8)
				{
					System.out.println("Error reading from file \"" + filename + "\"");
					System.out.println(line);
					System.out.println(st.countTokens());
					System.exit(1);
				}

				Integer id = new Integer(st.nextToken());
				String name = st.nextToken();
				Double latitude=new Double(st.nextToken());
				Double longitude=new Double(st.nextToken());
				ArrayList<String> cuisines = tokenizeString(st.nextToken());
				Double average_cost_for_two=new Double(st.nextToken());
				Double price_range=new Double(st.nextToken());
				Double aggregate_rating=new Double(st.nextToken());

				RestaurantCase restaurant = new RestaurantCase(id, name,latitude,longitude,cuisines,average_cost_for_two,price_range,aggregate_rating);
				cb.addCase(id, restaurant);
				//Creating a list of all cuisines with corresponding restaurantIds
				for(String str:cuisines){
					Set<Integer> restaurantList = (cuisineList.containsKey(str)
							? cuisineList.get(str) : new HashSet<Integer>());
					restaurantList.add(id);
					cuisineList.put(str,restaurantList);
				}
			}

			br.close();
		}
		catch(IOException e)
		{
			e.printStackTrace();
			System.exit(0);
		}
	}


	private ArrayList<String> tokenizeString(final String str)
	{
		ArrayList<String> al = new ArrayList<String>();

		StringTokenizer st = new StringTokenizer(str,";");
		while (st.hasMoreTokens())
			al.add(st.nextToken().trim()); 

		return al;
	}

	
	private void calculatecuisineSimMatrix() {
		maxSim = 0.0;
		cuisineSimMetric = new HashMap<String,Map<String,Double>>();
		double sim = 0.0;
		for (String cuisine1 : cuisineList.keySet()) {
			Map<String,Double> cuisine2Metric = (cuisineSimMetric.containsKey(cuisine1)
					? cuisineSimMetric.get(cuisine1) : new HashMap<String,Double>());
			for (String cuisine2 : cuisineList.keySet()) {
				if (cuisine1 != cuisine2) {
					sim = getSimWeight(cuisine1, cuisine2);	
					maxSim = (maxSim < sim) ? sim : maxSim;
					cuisine2Metric.put(cuisine2,sim);
				}
			}
			cuisineSimMetric.put(cuisine1, cuisine2Metric);
		}
	}

	
	private double getSimWeight(String cuisine1, String cuisine2){
		double confcuisine1_cuisine2 = 0.0, suffcuisine1_cuisine2 = 0.0;

		Set<Integer> restaurant_cuisine1 = cuisineList.get(cuisine1);
		Set<Integer> restaurant_cuisine2 = cuisineList.get(cuisine2);
		int count = 0;
		for(Integer restaurant: restaurant_cuisine1){
			if(restaurant_cuisine2.contains(restaurant)){
				count += 1;
			}
		}
		confcuisine1_cuisine2 = (double)((double)count/(double)cuisineList.get(cuisine1).size());

		double cuisinecount = (double)(cuisineList.get(cuisine2).size() - count);
		double compcuisine1Count = (double)(cb.getIds().size() - cuisineList.get(cuisine1).size());

		if(compcuisine1Count!=0){
			suffcuisine1_cuisine2 = cuisinecount/compcuisine1Count; 
		}else{
			suffcuisine1_cuisine2 = 0.0; 
		}

		if(suffcuisine1_cuisine2!=0)
		{
			return confcuisine1_cuisine2/suffcuisine1_cuisine2;
		}else{
			return 0.0;
		}
	}

	
	public double getSim(String cuisine1, String cuisine2){
		//System.out.println(cuisineSimMetric.get(cuisine1).get(cuisine2));;
		if(cuisineSimMetric.get(cuisine1).containsKey(cuisine2)){
			return cuisineSimMetric.get(cuisine1).get(cuisine2);
		}else{
			return 0.0;
		}

	}

	
	public double maxSim(){
		return maxSim;
	}
}


package snapr.cases;

import java.util.ArrayList;
import java.util.Set;
//A class that indicates a single case of user-restaurant rating class.
public class RatingCase {
	private Integer rid;
	private Integer uid;
	private Double rating;
	
	public RatingCase(final Integer rid, final Integer uid,final Double rating)
	{
		this.rid=rid;
		this.uid = uid;
		this.rating = rating;	
	}
	
	//Get the restaurant Id of the current rating object
	public Integer getId()
	{
		return this.rid;
	}
	//Get the user Id of the current rating object
	public Integer getUid()
	{
		return this.uid;
	}
	//Get the rating of the current rating object
	public Double getRating()
	{
		return this.rating;
	}
}

package snapr.cases;
//An interface that acts as a base class for all the case classes
public interface Case {
	
	/**
	 * @returns the case id
	 */
	public Integer getId();
}

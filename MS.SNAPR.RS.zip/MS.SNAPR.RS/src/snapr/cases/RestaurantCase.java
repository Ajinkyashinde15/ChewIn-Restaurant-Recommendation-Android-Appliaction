package snapr.cases;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

//An instance of this class indicates a single instance of a restaurant
public class RestaurantCase implements Case
{
	private Integer id; // the case id
	private String name; // the restaurant name
	private Double latitude; //location-latitude of the restaurant
	private Double longitude; //location-longitude of the restaurant
	private Set<String> cuisines; // the restaurant cuisines
	private Double average_cost_for_two; // the price for two people
	private Double price_range; // the price range
	private Double aggregate_rating; //aggregrate mean rating

   //constructor instantiates a restaurant object with only an id
	public RestaurantCase(final Integer id) {
		this.id = id;
		name = null;
		latitude=0.00;
		longitude=0.00;
		cuisines = new HashSet<String>();
		average_cost_for_two = 0.0;
		price_range = 0.0;
		aggregate_rating = 0.0;
	}

    //constructor instantiates a restaurant object with only an id, name, longitude, latitude,cuisines,average_cost_for_two,price_range,aggregate_rating
	public RestaurantCase(final Integer id, final String name,final Double latitude, final Double longitude, ArrayList<String> cuisines, 
			final Double average_cost_for_two, final Double price_range, final Double aggregate_rating)
	{
		this(id);
		this.name = name;
		for(String cuisine: cuisines)
			this.cuisines.add(cuisine);
		this.latitude = latitude;
		this.longitude = longitude;
		this.average_cost_for_two = average_cost_for_two;
		this.price_range = price_range;
		this.aggregate_rating = aggregate_rating;
	}

    //Get all the features for the current restaurant object

	public Integer getId()
	{
		return id;
	}


	public String getName()
	{
		return name;
	}

	public Double getLatitude()
	{
		return latitude;
	}

	public Double getLongitude()
	{
		return longitude;
	}


	public Set<String> getCuisines()
	{
		return cuisines;
	}

	public String getCuisineCSVFormat()
	{
		String csvCuisine="";
		int i=0;
		for(String c: this.cuisines)
		{
			if(i==(this.cuisines.size()-1))
			{
				csvCuisine+=c;
			}
			else
			{
				csvCuisine+=c+";";	
			}
			i++;
		}
		return csvCuisine;
	}


	public Double getAverageCost()
	{
		return average_cost_for_two;
	}


	public Double getPriceRange()
	{
		return price_range;
	}


	public Double getAggregateRating()
	{
		return aggregate_rating;
	}


	public String toString()
	{
		return id.toString() + " " + name + " " + cuisines.toString() + " " + average_cost_for_two.toString() + " " + price_range.toString()+ " " + aggregate_rating.toString();
	}
}



package snapr.recommender;

import java.util.ArrayList;
import java.util.Set;

import snapr.util.Matrix;
import snapr.util.reader.DataReader;
import snapr.similarity.SimilarityTask;

public abstract class RecommenderTask
{
	private Matrix matrix; // a Matrix object to store case similarities
	
	//Create a matrix like structure to store the scores in a row/column.
	public RecommenderTask(final SimilarityTask caseSimilarity, final DataReader reader)
	{
		// compute all case similarities and store in a Matrix object
		this.matrix = new Matrix();
		Set<Integer> ids = reader.getCasebase().getIds();
		for(Integer rowId: ids)
			for(Integer colId: ids)
				if(rowId.intValue() != colId.intValue())
				{
					double sim = caseSimilarity.getSimilarity(reader.getCasebase().getCase(rowId), reader.getCasebase().getCase(colId), reader);
					if(sim > 0)
						matrix.addElement(rowId, colId, sim);
				}
	}
	
	//Gets the similarity score between two restaurants when a rowid and column id provided.
	public Double getCaseSimilarity(final Integer rowId, final Integer colId)
	{
		return matrix.getElement(rowId, colId);
	}
	
	//Gets us the top ranked recommneded restaurants
	public abstract ArrayList<Integer> getRecommendations(final Integer userId, final DataReader reader);
	
}

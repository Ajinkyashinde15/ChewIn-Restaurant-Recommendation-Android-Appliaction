package snapr.recommender;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import snapr.util.ScoredThingDsc;
import snapr.util.reader.DataReader;
import snapr.similarity.SimilarityTask;


//A method that calculates the overall similarity score between two restaurants taking into consideration all the features.
//One restaurant being the candidate restaurant while the other being the top rated restaurants of the current user.
//Once we get similarity scores for a candidate restaurant with all the top restaurants, the highest score among them is assigned to the candidate restaurant.
//And the top scored restaurants are recommended
public class MaxRecommenderTask extends RecommenderTask
{
	
	public MaxRecommenderTask(final SimilarityTask caseSimilarity, final DataReader reader)
	{
		super(caseSimilarity, reader);
	}
	
	
	public ArrayList<Integer> getRecommendations(final Integer userId, final DataReader reader)
	{
		SortedSet<ScoredThingDsc> ss = new TreeSet<ScoredThingDsc>(); 
		
		// get the target user profile
		Map<Integer,Double> profile = reader.getUserProfile(userId);

		// get the ids of all recommendation candidate cases
		Set<Integer> candidateIds = reader.getCasebase().getIds();
		
		// compute a score for all recommendation candidate cases
		for(Integer candidateId: candidateIds)
		{
			if(!profile.containsKey(candidateId)) // check that the candidate case is not already contained in the user profile
			{
				double score = 0;
				for(Integer id: profile.keySet()) 
				{
					Double sim = super.getCaseSimilarity(candidateId, id);
					score = (sim != null && score < sim) ? sim.doubleValue() : score;
				}				

				if(score > 0)
					ss.add(new ScoredThingDsc(score, candidateId)); 
			}
		}

		ArrayList<Integer> recommendationIds = new ArrayList<Integer>();
		
		for(Iterator<ScoredThingDsc> it = ss.iterator(); it.hasNext();)
		{
			ScoredThingDsc st = it.next();
			recommendationIds.add((Integer)st.thing);
		}
		
		return recommendationIds;
	}
}

package snapr.main;

import java.io.IOException;
import java.io.OutputStreamWriter;

import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import snapr.dal.FeedbackDAL;
import snapr.dal.UserDAL;

/**
 * Servlet implementation class FeedbackServlet
 * Handles all feedback related functionality
 */
@WebServlet("/FeedbackServlet")
public class FeedbackServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	FeedbackDAL feedbackDal=new FeedbackDAL();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public FeedbackServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 * Captures all the data from query string and saves a new record in the feedback table using feedback DAL.
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try 
		{
			int length = request.getContentLength();
			byte[] input = new byte[length];
			ServletInputStream sin = request.getInputStream();
			int c, count = 0 ;
			while ((c = sin.read(input, count, input.length-count)) != -1) {
				count +=c;
			}
			sin.close();

			String recievedString = new String(input);
			response.setStatus(HttpServletResponse.SC_OK);
			String segments[] = recievedString.split("&");

			String rating1 = segments[0];
			String s[]=rating1.split("=");
			Double rating= Double.parseDouble(s[1]);

			String comment1 = segments[1];
			String r[]=comment1.split("=");
			String comment= r[1];
			comment=comment.replace("%20", " ");


			//Add CheckIn to Database
			if(feedbackDal.GetConnection())
			{
				if(UserDAL.userid!=null)
				{
					feedbackDal.AddFeedback(UserDAL.userid, rating, comment);
					OutputStreamWriter writer = new OutputStreamWriter(response.getOutputStream());
					writer.write("Feedback Submitted");
					writer.flush();
					writer.close();
				}
				else
				{
					feedbackDal.AddFeedback(99999, rating, comment);
					OutputStreamWriter writer = new OutputStreamWriter(response.getOutputStream());
					writer.write("Feedback Submitted");
					writer.flush();
					writer.close();
				}
			}
		} 
		catch (IOException e) 
		{
			try
			{
				response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
				response.getWriter().print(e.getMessage());
				response.getWriter().close();
			} 
			catch (IOException ioe) 
			{
			}
		}
	}

}

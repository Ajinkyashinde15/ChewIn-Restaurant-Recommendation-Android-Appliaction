package snapr.main;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import snapr.recommender.MaxRecommenderTask;
import snapr.recommender.RecommenderTask;
import snapr.similarity.OverlapCaseSimilarityTask;
import snapr.similarity.SimilarityTask;
import snapr.util.reader.DataReader;
import snapr.restservice.*;
import snapr.cases.*;
import snapr.dal.*;
import snapr.csv.CsvWriter1;;

/**
 * Servlet implementation class main_rs_servlet
 */
@WebServlet("/AndroidServlet")
public class AndroidServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	UserDAL userDal=new UserDAL();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AndroidServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 * Captures the data from the mobile application about the user and processes it for login functionality,
	 * recommendation, also creates a csv file for restaurant and ratings table. 
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String username="",fname="",sname="",dob="",gender="",veg="",email="",cuisines="";
		try 
		{
			int length = request.getContentLength();
			byte[] input = new byte[length];
			ServletInputStream sin = request.getInputStream();
			int c, count = 0 ;
			while ((c = sin.read(input, count, input.length-count)) != -1) {
				count +=c;
			}
			sin.close();

			String recievedString = new String(input);
			response.setStatus(HttpServletResponse.SC_OK);
			String segments[] = recievedString.split("&");

			if(segments.length==1)
			{
				String username1 = segments[0];
				String u[]=username1.split("=");
				username = u[1];
				if(userDal.GetConnection())
				{
					if(userDal.GetUserByUserName(username)==null)
					{
						OutputStreamWriter writer = new OutputStreamWriter(response.getOutputStream());
						writer.write("No");
						writer.flush();
						writer.close();
						return;
					}
					else
					{
						OutputStreamWriter writer = new OutputStreamWriter(response.getOutputStream());
						writer.write("Yes");
						writer.flush();
						writer.close();
					}
				}
			}
			else
			{
				String username1 = segments[0];
				String u[]=username1.split("=");
				username = u[1];
				username=username.replace("%20", " ");

				String fname1 = segments[1];
				String f[]=fname1.split("=");
				fname= f[1];
				fname=fname.replace("%20", " ");

				String sname1 = segments[2];
				String s[]=sname1.split("=");
				sname= s[1];
				sname=sname.replace("%20", " ");

				String dob1 = segments[3];
				String d[]=dob1.split("=");
				dob= d[1];
				dob=dob.replace("%20", "");
				dob=dob.replace("%2F", "/");

				String gender1 = segments[4];
				String g[]=gender1.split("=");
				gender= g[1];

				String veg1 = segments[5];
				String v[]=veg1.split("=");
				veg= v[1];

				String email1 = segments[6];
				String e[]=email1.split("=");
				email= e[1];
				email=email.replace("%40", "@");

				String cuisines1 = segments[7];
				String c1[]=cuisines1.split("=");
				String c2[]=c1[1].split("%2C");
				cuisines= c2[0]+";"+c2[1]+";"+c2[2];
			}


			RestaurantsDao restroDao= new RestaurantsDao();
			RestaurantsDAL restroDal=new RestaurantsDAL();
			RatingDAL ratingDal= new RatingDAL();
			CsvWriter1 csv= new CsvWriter1();

			String path = getServletContext().getRealPath("WEB-INF/../");
			String trainFile = path+"WEB-INF"+File.separator+"dataset" + File.separator + "trainData.csv";
			String restaurantFile = path+ "WEB-INF"+File.separator+"dataset" + File.separator + "snaprrestaurants.csv";


			
			if(restroDal.getConnection())
			{
				ArrayList<RestaurantCase>restros=restroDal.GetAllRestaurants();
				csv.RestaurantCSVWriter(restros,restaurantFile);
			}
			if(ratingDal.GetConnection())
			{
				ArrayList<RatingCase>ratings=ratingDal.GetRatings();
				csv.RatingsCSVWriter(ratings,trainFile);
			}
			
			

			DataReader reader= new DataReader(trainFile,restaurantFile);
			SimilarityTask caseSimilarity = new OverlapCaseSimilarityTask();

			RecommenderTask recommender= new MaxRecommenderTask(caseSimilarity, reader);
			//Add Users to Database
			if(userDal.GetConnection())
			{
				if(userDal.GetUserByUserName(username)==null)
				{
					userDal.AddUser(username, fname, sname, dob, Integer.parseInt(gender), Integer.parseInt(veg), cuisines, email);
					if(userDal.GetConnection())
					{
						UserDAL.userid=userDal.GetUserByUserName(username);
					}
					if(restroDal.getConnection())
					{
						ArrayList<Integer> recommendedIds=restroDal.GetAllRestaurantsByCuisine(cuisines);
						restroDao.GetRecommendedRestaurantsFromAPI(recommendedIds);
					}

				}
				else
				{
					UserDAL.userid=userDal.GetUserByUserName(username);
					OutputStreamWriter writer = new OutputStreamWriter(response.getOutputStream());
					writer.write("User already exists");
					writer.flush();
					writer.close();
					ArrayList<Integer> recommendedIds=recommender.getRecommendations(userDal.userid, reader);
					restroDao.GetRecommendedRestaurantsFromAPI(recommendedIds);
				}
			}
		} 
		catch (IOException e) 
		{
			try
			{
				response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
				response.getWriter().print(e.getMessage());
				response.getWriter().close();
			} 
			catch (IOException ioe) 
			{
			}
		}
	}

}


package snapr.main;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import snapr.dal.RestaurantsDAL;
import snapr.restservice.RestaurantsDao;

/**
 * Servlet implementation class MenuServlet
 */
@WebServlet("/MenuServlet")
public class MenuServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 * Handles all menu based search functionality requests
	 */
	public MenuServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 * Gets the parameters from the query string sent from android and searches the database for the restaurants with the menu item using Restaurant DAL.
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RestaurantsDao restroDao= new RestaurantsDao();
		RestaurantsDAL restroDal=new RestaurantsDAL();



		try 
		{
			int length = request.getContentLength();
			byte[] input = new byte[length];
			ServletInputStream sin = request.getInputStream();
			int c, count = 0 ;
			while ((c = sin.read(input, count, input.length-count)) != -1) {
				count +=c;
			}
			sin.close();

			String recievedString = new String(input);
			response.setStatus(HttpServletResponse.SC_OK);
			String segments[] = recievedString.split("=");

			
			String menu1 = segments[1];
			String m[]=menu1.split("&");
			String menu = m[0];
			
			//Searches restaurant table for the give menu using Restaurant DAL.
			if(restroDal.getConnection())
			{
				ArrayList<Integer>Ids=restroDal.GetAllRestaurantsByMenu(menu);
				restroDao.GetMenuRestaurantsFromAPI(Ids);
			}
			if(restroDao.GetMenuRestaurants().isEmpty())
			{
		
				OutputStreamWriter writer = new OutputStreamWriter(response.getOutputStream());

				writer.write("No Restaurants were found");
				writer.flush();
				writer.close(); 
			} 
			

		} 
		catch (IOException e) 
		{
			try
			{
				response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
				response.getWriter().print(e.getMessage());
				response.getWriter().close();
			} 
			catch (IOException ioe) 
			{
			}
		}
	}

}

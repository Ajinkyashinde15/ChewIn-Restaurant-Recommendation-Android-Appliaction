package snapr.main;

import java.io.IOException;
import java.io.OutputStreamWriter;

import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import snapr.dal.CheckInDAL;
import snapr.dal.RatingDAL;
import snapr.dal.UserDAL;

/**
 * Servlet implementation class RatingServlet
 */
@WebServlet("/RatingServlet")
public class RatingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	RatingDAL ratingDal=new RatingDAL();
       
    /**
     * @see HttpServlet#HttpServlet()
	 * Handles all the rating based fucntionality in our application.
     */
    public RatingServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 * Gets the user parameters from the android application and creates a new record in the rating table if the user has not rated the restaurant previously
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		try 
		{
			int length = request.getContentLength();
			byte[] input = new byte[length];
			ServletInputStream sin = request.getInputStream();
			int c, count = 0 ;
			while ((c = sin.read(input, count, input.length-count)) != -1) {
				count +=c;
			}
			sin.close();

			String recievedString = new String(input);
			response.setStatus(HttpServletResponse.SC_OK);
			String segments[] = recievedString.split("=");

			String username1 = segments[1];
			String u[]=username1.split("&");
			String username = u[0];

			String resid1 = segments[2];
			String r[]=resid1.split("&");
			Integer resid= Integer.parseInt(r[0]);

			String rating1 = segments[3];
			String s[]=rating1.split("&");
			Double rating= Double.parseDouble(s[0]);
			
			//Add CheckIn to Database
			if(ratingDal.GetConnection())
			{
				if(ratingDal.GetRatingByUserID(UserDAL.userid,resid)==false)
				{
					ratingDal.AddRating(UserDAL.userid,resid,rating);
				}
				else
				{
					OutputStreamWriter writer = new OutputStreamWriter(response.getOutputStream());

					writer.write("Already Rated");
					writer.flush();
					writer.close();
				}
			}
		} 
		catch (IOException e) 
		{
			try
			{
				response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
				response.getWriter().print(e.getMessage());
				response.getWriter().close();
			} 
			catch (IOException ioe) 
			{
			}
		}
	}

}

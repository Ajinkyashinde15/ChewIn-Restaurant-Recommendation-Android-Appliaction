package snapr.main;

import java.io.IOException;
import java.io.OutputStreamWriter;

import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import snapr.dal.BookmarksDAL;
import snapr.dal.UserDAL;

/**
 * Servlet implementation class BookmarkServlet
 * Takes care of all the bookmark related functionality
 */
@WebServlet("/BookmarkServlet")
public class BookmarkServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BookmarkServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 * captures the bookmark data from the android application and calls the Bookmark DAL to create a new record in the bookmark table 
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		BookmarksDAL bookmarksDal=new BookmarksDAL();
		try 
		{
			int length = request.getContentLength();
			byte[] input = new byte[length];
			ServletInputStream sin = request.getInputStream();
			int c, count = 0 ;
			while ((c = sin.read(input, count, input.length-count)) != -1) {
				count +=c;
			}
			sin.close();

			String recievedString = new String(input);
			response.setStatus(HttpServletResponse.SC_OK);
			String segments[] = recievedString.split("=");

			String username1 = segments[1];
			String u[]=username1.split("&");
			String username = u[0];
			
			String resid1 = segments[2];
			String f[]=resid1.split("&");
			Integer resid= Integer.parseInt(f[0]);
			
			String resname1 = segments[3];
			String r[]=resname1.split("&");
			String resname= r[0];
			resname=resname.replace("%20", " ");

			String longitude1 = segments[4];
			String s[]=longitude1.split("&");
			Double longitude= Double.parseDouble(s[0]);

			String latitude1 = segments[5];
			String d[]=latitude1.split("&");
			Double latitude= Double.parseDouble(d[0]);
			
			//Add Bookmarks to Database
			if(bookmarksDal.GetConnection())
			{
				if(bookmarksDal.GetBookmarkByUserID(UserDAL.userid,resid)==false)
				{
					bookmarksDal.AddBookmark(UserDAL.userid, resid, resname, longitude, latitude);
				}
				else
				{
					OutputStreamWriter writer = new OutputStreamWriter(response.getOutputStream());

					writer.write("Bookmark already exists");
					writer.flush();
					writer.close();
				}
			}

			  

		} 
		catch (IOException e) 
		{
			try
			{
				response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
				response.getWriter().print(e.getMessage());
				response.getWriter().close();
			} 
			catch (IOException ioe) 
			{
			}
		}
	}

}

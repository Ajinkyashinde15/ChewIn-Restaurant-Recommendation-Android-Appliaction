package snapr.dal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


//A Data Access Layer object to access the feedback table in the database
public class FeedbackDAL {

	Connection connection = null;
	String local="chewin.\"Feedback\"";
	String server="chewin.feedback";
	
	String localDB="jdbc:postgresql://localhost:8080/MS.SNAPR";
	String serverDB="jdbc:postgresql://127.0.0.1:5432/dbchewin";


    //Creates and sets up a connection with the database.
	public boolean GetConnection()
	{
		System.out.println("-------- PostgreSQL--JDBC Connection Testing ------------");
		try 
		{
			Class.forName("org.postgresql.Driver");
		} 
		catch (ClassNotFoundException e) 
		{
			System.out.println("Where is your PostgreSQL JDBC Driver? "+ "Include in your library path!");
			e.printStackTrace();
			return false;
		}

		System.out.println("PostgreSQL JDBC Driver Registered!");
		try 
		{
			//connection = DriverManager.getConnection("jdbc:postgresql://localhost:8080/MS.SNAPR", "postgres","qwerty");
			connection = DriverManager.getConnection(serverDB, "teamsnapr","k@s@steam");

		} 
		catch (SQLException sqlException) 
		{
			System.out.println("Connection Failed! Check output console");
			sqlException.printStackTrace();
			return false;
		}

		if (connection != null) 
		{
			System.out.println("You made it, take control your database now!");
			return true;
		} else 
		{
			System.out.println("Failed to make connection!");
			return false;
		}
	}

   //Add a feedback to the feedback table
	public boolean AddFeedback(Integer userid, Double rating, String comment)
	{
		Statement stmt = null;
		try
		{
			stmt = connection.createStatement();
			String sql = "INSERT INTO "+server+" (userid,rating,comment) "
					+ "VALUES ("+userid+", "+rating+", '"+comment+"')";
			stmt.executeUpdate(sql);
			stmt.close();
			connection.close();
			return true;
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			return false;
		}
	}
	
	//Get a feedback for a given user id
	public boolean GetFeedbackByUserID(Integer userid)
	{
		boolean isRatingPresent=false;
		Double rating=null;
		try
		{
			PreparedStatement st = connection.prepareStatement("SELECT * FROM "+server+" WHERE userid="+userid);
			ResultSet rs = st.executeQuery();
			while (rs.next())
			{
				rating=rs.getDouble("rating");

			}
			if(rating==null)
			{
				isRatingPresent= false;
			}
			else
			{
				isRatingPresent= true;
			}
			rs.close();
			st.close();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return isRatingPresent;
	}
}



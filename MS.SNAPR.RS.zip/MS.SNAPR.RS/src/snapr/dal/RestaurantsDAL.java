package snapr.dal;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.StringTokenizer;
import java.lang.System;
import snapr.cases.*;


//A Data Access Layer object to access the restaurants table in the database
public class RestaurantsDAL 
{
	Connection connection = null;
	String localDB="jdbc:postgresql://localhost:8080/MS.SNAPR";
	String serverDB="jdbc:postgresql://127.0.0.1:5432/dbchewin";
	
	String local="chewin.\"Restaurants\"";
	String server="chewin.restaurants";

	//Creates and sets up a connection with the database.
	public boolean getConnection()
	{
		System.out.println("-------- PostgreSQL--JDBC Connection Testing ------------");
		try 
		{
			Class.forName("org.postgresql.Driver");
		} 
		catch (ClassNotFoundException e) 
		{
			System.out.println("Where is your PostgreSQL JDBC Driver? "+ "Include in your library path!");
			e.printStackTrace();
			return false;
		}

		System.out.println("PostgreSQL JDBC Driver Registered!");
		try 
		{
			//connection = DriverManager.getConnection("jdbc:postgresql://localhost:8080/MS.SNAPR", "postgres","qwerty");
			connection = DriverManager.getConnection(serverDB, "teamsnapr","k@s@steam");

		} 
		catch (SQLException sqlException) 
		{
			System.out.println("Connection Failed! Check output console");
			sqlException.printStackTrace();
			return false;
		}

		if (connection != null) 
		{
			System.out.println("You made it, take control your database now!");
			return true;
		} else 
		{
			System.out.println("Failed to make connection!");
			return false;
		}
	}

    //Get all the restaurants that contains the menu item and rank them by aggregate rating
	public ArrayList<Integer> GetAllRestaurantsByMenu(String item)
	{
		ArrayList<Integer>Ids=new ArrayList<Integer>();
		try
		{
			PreparedStatement st = connection.prepareStatement("SELECT * FROM "+server+" WHERE LOWER(menu) LIKE LOWER('%"+item+"%') ORDER BY AGGREGRATE_RATING DESC");
			ResultSet rs = st.executeQuery();
			while (rs.next())
			{
				int ID=rs.getInt("id");
				Ids.add(ID);	
			}
			rs.close();
			st.close();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return Ids;
	}

  //Get all the restaurants that contains the given cuisines.
	public ArrayList<Integer> GetAllRestaurantsByCuisine(String cuisine)
	{
		ArrayList<Integer>Ids=new ArrayList<Integer>();
		try
		{
			String[] allCuisines=	cuisine.split(";");
			for(String c:allCuisines)
			{
				String sql="SELECT * FROM "+server+" WHERE LOWER(cuisine) LIKE LOWER('%"+c+"%')";
				PreparedStatement st = connection.prepareStatement(sql);
				ResultSet rs = st.executeQuery();
				while (rs.next())
				{
					int ID=rs.getInt("id");
					Ids.add(ID);	
				}
				rs.close();
				st.close();
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return Ids;
	}

    //Adds a new restaurant into the restaurant table.
	public boolean AddRestaurant(Integer id, String name, double longitude, double latitude, String cuisine,long average_cost, long aggregrate_rating, String menu)
	{
		Statement stmt = null;
		try
		{
			stmt = connection.createStatement();
			String sql = "INSERT INTO "+server+" (id,name,longitude,latitude,cuisine,average_cost,aggregrate_rating,menu) "
					+ "VALUES ("+id+",'"+name+"', "+longitude+", "+latitude+",'"+cuisine+"',"+average_cost+","+aggregrate_rating+",'"+menu+"')";
			stmt.executeUpdate(sql);
			stmt.close();
			connection.close();
			return true;
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			return false;
		}
	}

    //Gets all restaurants stored in the database.
	public ArrayList<RestaurantCase> GetAllRestaurants()
	{
		ArrayList<RestaurantCase>restros=new ArrayList<RestaurantCase>();
		try
		{
			String sql="SELECT * FROM "+server;
			PreparedStatement st = connection.prepareStatement(sql);
			ResultSet rs = st.executeQuery();
			while (rs.next())
			{
				int id=rs.getInt("id");
				String name=rs.getString("name");
				Double longitude= new Double(rs.getString("longitude"));
				Double latitude= new Double(rs.getString("latitude"));
				ArrayList<String> cuisines= tokenizeString(rs.getString("cuisine"));
				Double average_cost= new Double(rs.getString("average_cost"));
				Double price_range= new Double(rs.getString("price_range"));
				Double aggregate_rating= new Double(rs.getString("aggregrate_rating"));
				RestaurantCase restaurant = new RestaurantCase(id, name,latitude,longitude,cuisines,average_cost,price_range,aggregate_rating);
				
				restros.add(restaurant);	
			}
			rs.close();
			st.close();

		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return restros;
	}
	
	//Tokenize the string sperated by ";" and store in Array string
	private ArrayList<String> tokenizeString(final String str)
	{
		ArrayList<String> al = new ArrayList<String>();

		StringTokenizer st = new StringTokenizer(str,";");
		while (st.hasMoreTokens())
			al.add(st.nextToken().trim()); 

		return al;
	}
}


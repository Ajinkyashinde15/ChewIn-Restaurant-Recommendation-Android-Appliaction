package snapr.dal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

//A Data Access Layer object to access the users table in the database
public class UserDAL {

	Connection connection = null;
	public static Integer userid=null;
	public static String username=null;
	
	String localDB="jdbc:postgresql://localhost:8080/MS.SNAPR";
	String serverDB="jdbc:postgresql://127.0.0.1:5432/dbchewin";
	
	String local="chewin.\"User\"";
	String server="chewin.user";
	
    //Creates and sets up a connection with the database.
	public boolean GetConnection()
	{
		System.out.println("-------- PostgreSQL--JDBC Connection Testing ------------");
		try 
		{
			Class.forName("org.postgresql.Driver");
		} 
		catch (ClassNotFoundException e) 
		{
			System.out.println("Where is your PostgreSQL JDBC Driver? "+ "Include in your library path!");
			e.printStackTrace();
			return false;
		}

		System.out.println("PostgreSQL JDBC Driver Registered!");
		try 
		{
			//connection = DriverManager.getConnection("jdbc:postgresql://localhost:8080/MS.SNAPR", "postgres","qwerty");
			connection = DriverManager.getConnection(serverDB, "teamsnapr","k@s@steam");

		} 
		catch (SQLException sqlException) 
		{
			System.out.println("Connection Failed! Check output console");
			sqlException.printStackTrace();
			return false;
		}

		if (connection != null) 
		{
			System.out.println("You made it, take control your database now!");
			return true;
		} else 
		{
			System.out.println("Failed to make connection!");
			return false;
		}
	}
   
   //Gets the user by username
	public Integer GetUserByUserName(String username)
	{
		try
		{
			PreparedStatement st = connection.prepareStatement("SELECT * FROM "+server+" WHERE LOWER(username) LIKE LOWER('"+username+"')");
			ResultSet rs = st.executeQuery();
			if (!rs.isBeforeFirst() ) 
			{
				UserDAL.userid=null;
				
			}
			else
			{
				while (rs.next())
				{
					UserDAL.userid=rs.getInt("userid");
					UserDAL.username=rs.getString("username");
				}
			}
			rs.close();
			st.close();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return userid;
	}

    //Adds a new user
	public boolean AddUser(String username, String firstname, String lastname, String dateofbirth, Integer gender,Integer vegetarian, String cuisines, String email)
	{
		Statement stmt = null;
		DateFormat df = new SimpleDateFormat("dd/mm/yyyy");
		try
		{
			stmt = connection.createStatement();
			Date dob=df.parse(dateofbirth);
			String sql = "INSERT INTO "+server+" (username,firstname,lastname,dateofbirth,gender,vegetarian,cuisines,email) "
					+ "VALUES ('"+username+"', '"+firstname+"', '"+lastname+"','"+dob+"',"+gender+","+vegetarian+",'"+cuisines+"','"+email+"')";
			stmt.executeUpdate(sql);
			stmt.close();
			connection.close();
			return true;
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			return false;
		}
		catch(ParseException e)
		{
			e.printStackTrace();
			return false;
		}
	}
}


package snapr.featuresimilarity;

import java.util.Set;

import snapr.util.reader.DataReader;

public class FeatureSimilarity 
{
	
	//Overlap similarity score for two cuisines.
	public static double overlapForCuisne(final Set<String> s1, final Set<String> s2,DataReader reader) 
	{
		double intersection = 0;
		
		for(String cuisine1 : s1){
			for(String cuisine2 : s2){
				if(reader.getSim(cuisine1, cuisine2) != 0){
					//System.out.println(reader.getSim(genre1, genre2));
				}
				intersection += reader.getSim(cuisine1, cuisine2)/reader.maxSim();
			}
		}
		if(intersection!=0){
		//	System.out.println(intersection);
		}
		return intersection/(s1.size()+s2.size());
	}
	
	
	
	public static double Symmetric(final Double d1, final Double d2) 
	{
		return (1 - (Math.abs(d1-d2)/d2));		
	}
	
	//Asymmetric similarity score between two numerical features.
	public static double Asymmetric(final Double d1, final Double d2) 
	{
		if(d1 > d2){
			return (1 - (Math.abs(d1-d2)/d1));	
		}
		else{
			return (1 - (Math.abs(d1-d2)/d2));
		}
	}
}

package snapr.similarity;

import snapr.cases.Case;
import snapr.cases.RestaurantCase;
import snapr.featuresimilarity.FeatureSimilarity;
import snapr.util.reader.DataReader;

public class OverlapCaseSimilarityTask implements SimilarityTask
{
	final static double CUISINE_WEIGHT = 1; 
	final static double PRICE_WEIGHT = 1; 
	final static double COST_WEIGHT = 1; 
	final static double RATING_WEIGHT = 1; 
	
	public OverlapCaseSimilarityTask()
	{}

	
	public double getSimilarity(final Case c1, final Case c2, DataReader reader) 
	{
		RestaurantCase r1 = (RestaurantCase)c1;
		RestaurantCase r2 = (RestaurantCase)c2;

		double above = CUISINE_WEIGHT * FeatureSimilarity.overlapForCuisne(r1.getCuisines(), r2.getCuisines(),reader)+
				COST_WEIGHT* FeatureSimilarity.Asymmetric(r1.getAverageCost(), r2.getAverageCost()) +
				PRICE_WEIGHT* FeatureSimilarity.Asymmetric(r1.getPriceRange(), r2.getPriceRange()) +
				RATING_WEIGHT * FeatureSimilarity.Asymmetric(r1.getAggregateRating(), r2.getAggregateRating());

		double below = CUISINE_WEIGHT;

		return (below > 0) ? above / below : 0;
	}
}

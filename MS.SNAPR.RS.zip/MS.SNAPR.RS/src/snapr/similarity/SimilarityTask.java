

package snapr.similarity;

import snapr.cases.Case;
import snapr.util.reader.DataReader;

public interface SimilarityTask
{
	public double getSimilarity(final Case c1, final Case c2, DataReader reader);
}

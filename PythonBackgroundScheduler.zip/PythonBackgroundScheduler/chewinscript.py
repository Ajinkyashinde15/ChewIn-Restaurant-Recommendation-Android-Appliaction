#!/home/student/chewin/venv/bin/python
import sys
import requests
import pandas as pd
import psycopg2
conn = None
try:
    #conn = psycopg2.connect("dbname='dbchewin' user='teamsnapr' host='http://csi6220-2-vm1.ucd.ie' password='k@s@steam' port='5432' sslmode='require'")
    conn = psycopg2.connect("dbname='dbchewin' user='teamsnapr' host='127.0.0.1' password='k@s@steam' port='5432'")
    
    cur = conn.cursor()
    
    from pprint import pprint

    start=0
    print ("Innitializing...")
    print ("...")
    
    #cur.execute("CREATE TABLE public.restaurantstbl(rid character varying(200) NOT NULL, name character varying(200), latitude double precision, longitude double precision, cuisines text, average_cost_for_two money, price_range numeric, aggregate_rating double precision, menu text, CONSTRAINT pry_key PRIMARY KEY (rid) );")
    #conn.commit()
    
    cols=['id','name','latitude','longitude','cuisines','average_cost_for_two','price_range','aggregate_rating','menu']
    df = pd.DataFrame(columns=cols)
    for i in range(5):
        url = "https://developers.zomato.com/api/v2.1/search?entity_id=91&entity_type=city&start="+str(start)+"&lat=53.3366965&lon=-6.2490116&sort=real_distance&order=desc"
        header = {"User-agent": "curl/7.43.0", "Accept": "application/json", "user_key": "b3021361dc5ad608c9dc5a9afc41645e"}
        response = requests.get(url, headers=header)
        start=start+20
        count = 0
        res=response.json()
        restro=res['restaurants']
        for j in range(len(restro)):
            id=restro[j]['restaurant']['id']
            name=restro[j]['restaurant']['name']
            latitude=restro[j]['restaurant']['location']['latitude']
            longitude=restro[j]['restaurant']['location']['longitude']
            cuisines=restro[j]['restaurant']['cuisines']
            cuisines = cuisines.replace(",", ";")
            average_cost_for_two=restro[j]['restaurant']['average_cost_for_two']
            price_range=restro[j]['restaurant']['price_range']
            aggregate_rating=restro[j]['restaurant']['user_rating']['aggregate_rating']
            count = count+1
            print ("Writing line..." + str(count))
            allData=pd.read_csv('/home/student/chewin/snapr_restaurants.csv',usecols=cols)
            if(int(id) not in allData.id.values):
                menu_url = "https://developers.zomato.com/api/v2.1/dailymenu?res_id="+id;
                menu_response = requests.get(menu_url,headers=header)
                menu_res=menu_response.json()
                menu=""
                if(menu_res['status']!="Bad Request"):
                    dailymenus=menu_res['daily_menus']
                    for i in range(len(dailymenus)):
                        dishes=dailymenus[i]["daily_menu"]["dishes"]
                        for k in range(len(dishes)):
                            dish_name=dishes[k]["dish"]["name"]
                            menu=menu+";"+dish_name
                
                s = pd.Series([id, name, latitude,longitude,cuisines,average_cost_for_two,price_range,aggregate_rating,menu],index=cols)
                df = df.append(s, ignore_index=True)
                print (id)
                query = "INSERT INTO public.restaurantstbl (id, name, latitude, longitude, cuisines, average_cost_for_two, price_range, aggregate_rating, menu) \
                                                          VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s)"
                data = (id, name, latitude, longitude, cuisines, average_cost_for_two, price_range, aggregate_rating, menu)
                cur.execute(query, data)
                conn.commit()
    df.to_csv('/home/student/chewin/snapr_restaurants.csv',sep=',',mode='a',header=False,index=False, encoding='utf-8')
    print ("...Finished writing into the Database")

#except:
#    print ("Sorry! I cannot connect to the database at the moment, Please consult the administrator")

except psycopg2.DatabaseError as e:
    
    if conn:
        conn.rollback()
    
    print ('Error:', e)    
    sys.exit(1)
    
    
finally:
    
    if conn:
        conn.close() 
